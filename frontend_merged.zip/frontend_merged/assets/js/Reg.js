document.getElementById('registerForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    console.log("A regisztrációs form beküldve.");

    var firstname = document.getElementById('firstname').value.trim();
    var lastname = document.getElementById('lastname').value.trim();
    var email = document.getElementById('email').value.trim();
    var phone = document.getElementById('phone').value.trim();
    var password = document.getElementById('reg_password').value.trim();
    var username = document.getElementById('reg_username').value.trim();
    var msgDiv = document.getElementById('registerMessage');
    
    msgDiv.textContent = '';  // Töröljük a régi hibaüzeneteket
    msgDiv.classList.remove('show');  // Üzenet elrejtése

    // Ellenőrzések először
    const nameRegex = /^[a-zA-ZáéíóöőúüűÁÉÍÓÖŐÚÜŰ]+$/;
    if (!nameRegex.test(firstname)) {
        msgDiv.style.color = 'red';
        msgDiv.textContent = "A keresztnév csak betűket tartalmazhat!";
        msgDiv.classList.add('show');
        return;
    }
    if (!nameRegex.test(lastname)) {
        msgDiv.style.color = 'red';
        msgDiv.textContent = "A vezetéknév csak betűket tartalmazhat!";
        msgDiv.classList.add('show');
        return;
    }

    // Email validálása
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!emailRegex.test(email)) {
        msgDiv.style.color = 'red';
        msgDiv.textContent = "Érvénytelen email formátum!";
        msgDiv.classList.add('show');
        return;
    }

    // Telefonszám validálása (formátum + ismétlődő számok kizárása)
    const phoneRegex = /^(?:\+36|06)[ ]?(20|30|31|50|70)[ ]?\d{3}[ ]?\d{4}$/;
    const repeatedDigitsRegex = /^(\d)\1{5,}$/;

    if (!phoneRegex.test(phone) || repeatedDigitsRegex.test(phone.replace(/\D/g, ''))) {
        msgDiv.style.color = 'red';
        msgDiv.textContent = "Érvénytelen telefonszám!";
        msgDiv.classList.add('show');
        return;
    }

    // Felhasználónév validálása
    const usernameRegex = /^[a-zA-ZáéíóöőúüűÁÉÍÓÖŐÚÜŰ0-9_]+$/;
    if (!username || !usernameRegex.test(username)) {
        msgDiv.style.color = 'red';
        msgDiv.textContent = "A felhasználónév csak betűket és számokat tartalmazhat, és nem lehet üres!";
        msgDiv.classList.add('show');
        return;
    }

    // Jelszó validálása
    if (password.length < 6) {
        msgDiv.style.color = 'red';
        msgDiv.textContent = "A jelszónak legalább 6 karakter hosszúnak kell lennie!";
        msgDiv.classList.add('show');
        return;
    }

    // Ha minden validálás rendben van, akkor küldd el a regisztrációs kérést
    fetch('http://localhost/backend/Controller/account.php', {
        method: 'POST',
        credentials: 'include',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            action: 'register',
            firstname: firstname,
            lastname: lastname,
            email: email,
            phonenumber: phone,
            username: username,
            password: password
        })
    })
    .then(response => {
        console.log("Szerver válasz:", response); 
        if (!response.ok) {
            throw new Error('Hiba történt a kérés feldolgozása közben!');
        }
        return response.json();
    })
    .then(data => {
        console.log("Szerver válasz:", data); 
        if (data.success) {
            window.location.href = "Login.html"; 
        } else {
            msgDiv.style.color = 'red';
            msgDiv.textContent = data.error || "Hiba történt a regisztráció során.";
            msgDiv.classList.add('show');
        }
    })
    .catch(error => {
        console.error('Hiba a regisztráció során:', error);  
        msgDiv.style.color = 'red';
        msgDiv.textContent = error.message || "Kapcsolódási hiba a szerverrel.";
        msgDiv.classList.add('show');
    });
});
