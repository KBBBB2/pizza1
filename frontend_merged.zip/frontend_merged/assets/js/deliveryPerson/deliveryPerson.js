// Kilépés gomb kezelése
document.getElementById('logoutBtn').addEventListener('click', function() {
    localStorage.removeItem("userRole");
    localStorage.removeItem("cart");
    localStorage.removeItem("token");
    window.location.href = "/view/customer/Login.html";
  });
  
  // Egyszerű értesítő üzenet megjelenítése az oldalra (3 másodpercig)
  function showNotification(message) {
    const notification = document.getElementById("notification");
    notification.textContent = message;
    notification.style.display = "block";
    setTimeout(() => {
      notification.style.display = "none";
    }, 3000);
  }
  
  // Rendelések betöltése (csak pending státuszú rendeléseket jelenítünk meg)
  function loadOrders() {
    const token = localStorage.getItem("token");
    fetch('http://localhost/backend/controller/delivery.php?action=readall', {
      headers: {
        'Authorization': 'Bearer ' + token
      }
    })
    .then(response => {
      if (!response.ok) {
        throw new Error("Hibás válasz a szervertől");
      }
      return response.json();
    })
    .then(data => {
      if (data.success) {
        const pendingOrders = data.deliveries.filter(order => order.status === 'pending');
        const tableBody = document.getElementById('ordersTableBody');
        tableBody.innerHTML = "";
        pendingOrders.forEach(order => {
          const tr = document.createElement('tr');
          
          const tdId = document.createElement('td');
          tdId.textContent = order.id;
          tr.appendChild(tdId);
          
          const tdAddress = document.createElement('td');
          tdAddress.textContent = order.address;
          tr.appendChild(tdAddress);
          
          const tdPhone = document.createElement('td');
          tdPhone.textContent = order.phonenumber;
          tr.appendChild(tdPhone);
          
          const tdAction = document.createElement('td');
          const pickupButton = document.createElement('button');
          pickupButton.className = "button";
          pickupButton.textContent = "Rendelés felvétele";
          pickupButton.addEventListener('click', function() {
            // Az adott rendelés adatait eltároljuk a localStorage-ban a részletekhez
            localStorage.setItem("selectedOrder", JSON.stringify(order));
            pickupOrder(order.id);
          });
          tdAction.appendChild(pickupButton);
          tr.appendChild(tdAction);
          
          tableBody.appendChild(tr);
        });
      } else {
        showNotification("Hiba az adatok betöltésekor: " + data.error);
      }
    })
    .catch(err => {
      console.error("Hiba a kérések során:", err);
      showNotification("Hiba történt az adatok betöltésekor!");
    });
  }
  
  // Rendelés felvétele: a status "in transit"-re módosítása
  function pickupOrder(orderId) {
    const token = localStorage.getItem("token");
    fetch('http://localhost/backend/controller/delivery.php?action=update', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + token
      },
      body: JSON.stringify({
        delivery_id: orderId,
        status: 'in transit'
      })
    })
    .then(response => {
      if (!response.ok) {
        throw new Error("Hibás válasz a szervertől");
      }
      return response.json();
    })
    .then(data => {
      if (data.success) {
        showNotification("Rendelés felvéve! Átlépünk a részletek oldalra.");
        window.location.href = "delivery.html";
      } else {
        showNotification("Hiba történt: " + data.error);
      }
    })
    .catch(err => {
      console.error("Hiba az order felvételnél:", err);
      showNotification("Hiba történt a rendelés felvételénél!");
    });
  }
  
  document.addEventListener('DOMContentLoaded', loadOrders);
  