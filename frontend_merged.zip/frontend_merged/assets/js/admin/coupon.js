// Global változók
let originalData = [];
let couponTypes = [];

// Modal bezárása
function closeModal() {
    const modal = document.getElementById('editModal');
    modal.style.display = 'none';
    modal.classList.remove('centered-modal');
}

// Kupon szerkesztése
function editCoupon(couponId) {
    const row = document.querySelector(`tr[data-id='${couponId}']`);
    const columns = row.querySelectorAll('td');

    originalData = {
        id: couponId,
        name: columns[1].textContent,
        description: columns[2].textContent,
        code: columns[3].textContent,
        discount_type: columns[4].textContent,
        discount_value: columns[5].textContent,
        expiration_date: columns[6].textContent,
        is_active: columns[7].textContent === "Aktív" ? 1 : 0
    };

    document.getElementById('editName').value = columns[1].textContent;
    document.getElementById('editDescription').value = columns[2].textContent;
    document.getElementById('editCode').value = columns[3].textContent;
    document.getElementById('editDiscountType').value = columns[4].textContent;
    document.getElementById('editDiscountValue').value = columns[5].textContent;
    document.getElementById('editExpirationDate').value = columns[6].textContent;
    document.getElementById('editIsActive').value = columns[7].textContent === "Aktív" ? 1 : 0;

    const modal = document.getElementById('editModal');
    modal.style.display = 'flex';
    modal.classList.add('centered-modal');

    document.getElementById('editCouponForm').dataset.couponId = couponId;
}

// Kupon mentése
function saveCoupon() {
    const couponId = document.getElementById('editCouponForm').dataset.couponId;

    const updatedData = {
        action: 'update',
        id: couponId,
        name: document.getElementById('editName').value,
        description: document.getElementById('editDescription').value,
        code: document.getElementById('editCode').value,
        discount_type: document.getElementById('editDiscountType').value,
        discount_value: document.getElementById('editDiscountValue').value,
        expiration_date: document.getElementById('editExpirationDate').value,
        is_active: document.getElementById('editIsActive').value
    };

    fetch('http://localhost/backend/Controller/adminCoupon.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedData)
    })
    .then(response => response.json())
    .then(() => {
        fetchCoupons();
        closeModal();
    })
    .catch(err => {
        console.error('Hiba:', err);
        alert('Hiba történt a kapcsolat során.');
    });
}

function cancelEdit() {
    document.getElementById('editName').value = originalData.name;
    document.getElementById('editDescription').value = originalData.description;
    document.getElementById('editCode').value = originalData.code;
    document.getElementById('editDiscountType').value = originalData.discount_type;
    document.getElementById('editDiscountValue').value = originalData.discount_value;
    document.getElementById('editExpirationDate').value = originalData.expiration_date;
    document.getElementById('editIsActive').value = originalData.is_active;

    closeModal();
}

// Kuponok lekérése és megjelenítése
function fetchCoupons() {
    fetch('http://localhost/backend/Controller/adminCoupon.php?action=read')
        .then(response => {
            if (!response.ok) throw new Error('Hiba történt a kuponok lekérése során');
            return response.json();
        })
        .then(data => {
            originalData = data;
            renderCoupons(data);
        })
        .catch(error => {
            console.error('Hiba:', error);
            alert('Hiba történt a kuponok betöltése során.');
        });
}

function renderCoupons(data) {
    const tbody = document.querySelector('#couponTable tbody');
    tbody.innerHTML = '';

    data.forEach(coupon => {
        const tr = document.createElement('tr');
        tr.setAttribute('data-id', coupon.id);
        tr.innerHTML = `
            <td>${coupon.id}</td>
            <td>${coupon.name}</td>
            <td>${coupon.description}</td>
            <td>${coupon.code}</td>
            <td>${coupon.discount_type}</td>
            <td>${coupon.discount_value}</td>
            <td>${coupon.expiration_date}</td>
            <td>${coupon.is_active == 1 ? "Aktív" : "Inaktív"}</td>
            <td class="action-buttons">
                <div style="display: flex; flex-direction: column; gap: 4px;">
                <button class="edit-btn" onclick="editCoupon(${coupon.id})">Szerkesztés</button>
                <button class="delete-btn" onclick="deleteCoupon(${coupon.id})">Törlés</button>
                </div>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

// Kupon törlése
function deleteCoupon(couponId) {
    const confirmation = confirm("Biztosan törli ezt a kupont?");
    if (confirmation) {
        const data = { action: 'delete', id: couponId };

        fetch('http://localhost/backend/Controller/adminCoupon.php', {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        })
        .then(response => response.json())
        .then(() => fetchCoupons())
        .catch(error => console.error('Hiba:', error));
    }
}

// Új kupon hozzáadása
document.getElementById('addCouponBtn').addEventListener('click', function () {
    const modal = document.getElementById('addCouponModal');
    modal.style.display = 'flex';
    modal.classList.add('centered-modal');
});

function closeAddCouponModal() {
    const modal = document.getElementById('addCouponModal');
    modal.style.display = 'none';
    modal.classList.remove('centered-modal');
}

document.getElementById('addCouponForm').addEventListener('submit', function (e) {
    e.preventDefault();

    const couponData = {
        action: 'create',
        name: document.getElementById('newName').value,
        description: document.getElementById('newDescription').value,
        code: document.getElementById('newCode').value,
        discount_type: document.getElementById('newDiscountType').value,
        discount_value: document.getElementById('newDiscountValue').value,
        expiration_date: document.getElementById('newExpirationDate').value,
        is_active: document.getElementById('newIsActive').value
    };

    fetch('http://localhost/backend/controller/adminCoupon.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(couponData)
    })
    .then(response => response.json())
    .then(() => {
        closeAddCouponModal();
        fetchCoupons();
    })
    .catch(err => {
        console.error("Hiba:", err);
        alert("Hiba történt a kapcsolat során.");
    });
});

// Élő szűrés a táblázatban
function handleLiveSearch() {
    const input = document.getElementById('couponTypeSearchInput').value.toLowerCase();
    const filteredData = originalData.filter(coupon => {
        return Object.values(coupon).some(val =>
            String(val).toLowerCase().includes(input)
        );
    });

    renderCoupons(filteredData);
}

document.addEventListener('DOMContentLoaded', function () {
    fetchCoupons();

    const searchInput = document.getElementById('couponTypeSearchInput');
    if (searchInput) {
        searchInput.addEventListener('input', handleLiveSearch);
    }
});
