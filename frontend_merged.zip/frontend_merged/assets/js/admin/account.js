// Függvény, amely lekéri az account rekordokat, opcionálisan keresési feltétellel
function loadAccounts(query = '') {
    let url = 'http://localhost/backend/Controller/adminAccount.php?action=getAccounts';
    if (query !== '') {
        url += '&q=' + encodeURIComponent(query);
    }

    fetch(url)
        .then(response => response.json())
        .then(accounts => {
            const tbody = document.querySelector('#accountsTable tbody');
            
            // Ellenőrizzük, hogy a tbody létezik
            if (!tbody) {
                console.error('A #accountsTable tbody elem nem található!');
                return;
            }

            tbody.innerHTML = ''; // Töröljük a meglévő sorokat

            accounts.forEach(account => {
                const row = document.createElement('tr');

                // Csak a szükséges oszlopok megjelenítése (id, password nélkül)
                row.innerHTML = `
                    <td>${account.firstname}</td>
                    <td>${account.lastname}</td>
                    <td>${account.username}</td>
                    <td>${account.email}</td>
                    <td>${account.phonenumber}</td>
                    <td>${account.created}</td>
                    <td>${account.locked == 1 ? 'Igen' : 'Nem'}</td>
                    <td>${account.disabled == 1 ? 'Igen' : 'Nem'}</td>
                    <td class="action-container">
                        <button class="temp-ban-btn btn btn-danger tban-button">Ideiglenes tiltás</button>
                        <button class="perm-ban-btn btn-danger pban-button">Végleges tiltás</button>
                    </td>
                `;

                tbody.appendChild(row);

                // Akciók gombok
                const tempBanBtn = row.querySelector('.temp-ban-btn');
                tempBanBtn.addEventListener('click', function () {
                    if (!row.querySelector('.tempDuration')) {
                        const durationInput = document.createElement('input');
                        durationInput.type = 'text';
                        durationInput.classList.add('tempDuration');
                        durationInput.placeholder = 'Pl. 5m, 2h, 1d';
                        const confirmBtn = document.createElement('button');
                        confirmBtn.textContent = 'Megerősít';
                        
                        confirmBtn.classList.add('btn', 'btn-danger', 'confirmBtn');

                        row.querySelector('.action-container').appendChild(durationInput);
                        row.querySelector('.action-container').appendChild(confirmBtn);

                        confirmBtn.addEventListener('click', function () {
                            const duration = durationInput.value;
                            fetch('http://localhost/backend/Controller/adminAccount.php', {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                                body: `action=tempBan&id=${account.id}&duration=${encodeURIComponent(duration)}`
                            })
                                .then(() => {
                                    alert("Ideiglenes tiltás: sikeresen végrehajtva");
                                    loadAccounts(document.getElementById('search').value); // Frissíti a listát
                                })
                                .catch(error => {
                                    console.error('Hiba történt a tiltás során:', error);
                                });
                        });
                    }
                });

                // Végleges tiltás
                const permBanBtn = row.querySelector('.perm-ban-btn');
                permBanBtn.addEventListener('click', function () {
                    if (confirm("Biztosan végleges tiltás?")) {
                        fetch('http://localhost/backend/Controller/adminAccount.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                            body: `action=permBan&id=${account.id}`
                        })
                            .then(() => {
                                alert("Végleges tiltás: sikeresen végrehajtva");
                                loadAccounts(document.getElementById('search').value); 
                            })
                            .catch(error => {
                                console.error('Hiba történt a végleges tiltás során:', error);
                            });
                    }
                });
            });
        })
        .catch(error => {
            console.error('Hiba történt a lekérés során:', error);
        });
}

// Oldal betöltésekor az account rekordok lekérése
document.addEventListener("DOMContentLoaded", function () {
    loadAccounts();

    // Live search eseménykezelője
    document.getElementById('search').addEventListener('input', function () {
        const query = document.getElementById('search').value;
        loadAccounts(query);
    });
});
