document.addEventListener("DOMContentLoaded", function () {
    const token = localStorage.getItem('token');
    const msgDiv = document.getElementById('msg');

    if (!token) {
        alert("Nincs érvényes token, kérlek jelentkezz be újra!");
        window.location.href = "login.html";
        return;
    }

    // Felhasználói adatok lekérése az oldal betöltésekor
    fetch('http://localhost/backend/Controller/account.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        },
        body: JSON.stringify({ action: 'getUserData' })
    })
        .then(response => response.json())
        .then(data => {
            if (data.user) {
                document.getElementById('lastname').value = data.user.lastname || "";
                document.getElementById('firstname').value = data.user.firstname || "";
                document.getElementById('username').value = data.user.username || "";
                document.getElementById('email').value = data.user.email || "";
                document.getElementById('phonenumber').value = data.user.phonenumber || "";
            } else {
                alert("Nem sikerült lekérni az adatokat: " + data.error);
            }
        })
        .catch(error => console.error('Error:', error));

    // Mentés gomb eseménykezelője
    document.querySelector('.save-button').addEventListener('click', function () {
        const firstname = document.getElementById('firstname').value.trim();
        const lastname = document.getElementById('lastname').value.trim();
        const username = document.getElementById('username').value.trim();
        const email = document.getElementById('email').value.trim();
        const phonenumber = document.getElementById('phonenumber').value.trim();
        const currentPassword = document.getElementById('current-password').value.trim();
        const newPassword = document.getElementById('new-password').value.trim();

        let isValid = true;
        msgDiv.textContent = "";
        msgDiv.classList.remove("show");

        // Üres mezők ellenőrzése
        const fields = ['firstname', 'lastname', 'username', 'email', 'phonenumber'];
        fields.forEach(field => {
            if (!document.getElementById(field).value.trim()) {
                showError(field, 'Minden mezőt ki kell tölteni!');
                isValid = false;
            } else {
                clearError(field);
            }
        });

        // Telefonszám validálása (formátum + ismétlődő számok kizárása)
        const phoneRegex = /^(?:\+36|06)[ ]?(20|30|31|50|70)[ ]?\d{3}[ ]?\d{4}$/;
        const repeatedDigitsRegex = /^(\d)\1{5,}$/;

        if (!phoneRegex.test(phonenumber) || repeatedDigitsRegex.test(phonenumber.replace(/\D/g, ''))) {
            isValid = false;
            showError('phonenumber', 'Érvénytelen telefonszám!');
        } else {
            clearError('phonenumber');
        }

        // Email validálása
        const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        if (!emailRegex.test(email)) {
            isValid = false;
            showError('email', 'Érvénytelen email formátum!');
        } else {
            clearError('email');
        }

        // Jelszó validálás
        if (newPassword && newPassword.length < 6) {
            isValid = false;
            showError('new-password', 'Az új jelszónak legalább 6 karakter hosszúnak kell lennie!');
        }

        if (newPassword && !currentPassword) {
            isValid = false;
            showError('current-password', 'Kérlek, add meg a jelenlegi jelszót, ha új jelszót szeretnél megadni!');
        }

        if (!isValid) return;

        const payload = {
            action: 'update',
            firstname,
            lastname,
            username,
            email,
            phonenumber,
            'current-password': currentPassword,
            'new-password': newPassword
        };

        fetch('http://localhost/backend/Controller/account.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + token
            },
            body: JSON.stringify(payload)
        })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    msgDiv.style.color = 'green';
                    msgDiv.textContent = "Sikeres módosítás!";
                    msgDiv.classList.add('show');
                } else {
                    msgDiv.style.color = 'red';
                    msgDiv.textContent = "Hiba: " + data.error;
                    msgDiv.classList.add('show');
                }
            })
            .catch(error => console.error('Error:', error));
    });

    // Segédfüggvények
    function showError(fieldId, message) {
        const inputField = document.getElementById(fieldId);
        let errorElement = inputField.parentElement.querySelector('.error-message');

        if (errorElement) errorElement.remove();

        errorElement = document.createElement('div');
        errorElement.className = 'error-message';
        errorElement.textContent = message;
        inputField.parentElement.appendChild(errorElement);
    }

    function clearError(fieldId) {
        const inputField = document.getElementById(fieldId);
        const errorElement = inputField.parentElement.querySelector('.error-message');
        if (errorElement) errorElement.remove();
    }
});
    