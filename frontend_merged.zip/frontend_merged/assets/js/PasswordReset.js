document.getElementById('resetPasswordForm').addEventListener('submit', function (e) {
    e.preventDefault();

    const usernameOrEmail = document.getElementById('reset_username').value;
    const messageDiv = document.getElementById('resetMessage');

    fetch('http://localhost/backend/Controller/account.php', {
        method: 'POST',
        credentials: 'include',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            action: 'reset_password',
            usernameOrEmail: usernameOrEmail
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            messageDiv.textContent = "A jelszó visszaállítási linket elküldtük az e-mail címedre.";
            messageDiv.style.color = "green";
        } else {
            messageDiv.textContent = data.error || "Hiba történt a jelszó visszaállítása során.";
            messageDiv.style.color = "red";
        }
    })
    .catch(error => {
        console.error("Hiba a jelszó visszaállítása során:", error);
        messageDiv.textContent = "Kapcsolódási hiba a szerverrel.";
        messageDiv.style.color = "red";
    });
});

// PasswordReset.js

// Függvény a query paraméterek kinyerésére
function getQueryParam(param) {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get(param);
}

// Token kinyerése
const token = getQueryParam('token');

if (!token) {
    // Ha nincs token az URL-ben, értesítjük a felhasználót, vagy átirányítjuk
    document.getElementById('resetMessage').textContent = 'Hozzáférés megtagadva: hiányzik a token.';
    // Esetleg átirányíthatjuk a felhasználót a bejelentkezési oldalra, vagy egy hiboldalra.
} else {
    // Itt folytathatod a tokennel kapcsolatos folyamatot,
    // például ellenőrizheted a token érvényességét egy fetch kérés segítségével.
    console.log("Token: ", token);
}

// További kód a jelszó visszaállító folyamat lebonyolításához
document.getElementById('resetPasswordForm').addEventListener('submit', function(e) {
    e.preventDefault();

    // Itt összegyűjtöd az új jelszót, majd elküldöd a backend felé, a tokennel együtt,
    // hogy érvényesítsék a visszaállítási kérést.
    const newPassword = document.getElementById('newPassword').value; // Példa, ha van ilyen input mező
    fetch('http://localhost/Controller/reset_password.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            token: token,
            newPassword: newPassword,
            action: 'reset'
        })
    })
    .then(response => response.json())
    .then(data => {
        if(data.success){
            document.getElementById('resetMessage').textContent = 'Sikeres jelszó módosítás.';
        } else {
            document.getElementById('resetMessage').textContent = data.error || 'Hiba történt a jelszó módosítása során.';
        }
    })
    .catch(error => {
        console.error('Hiba:', error);
        document.getElementById('resetMessage').textContent = 'Kapcsolódási hiba.';
    });
});
