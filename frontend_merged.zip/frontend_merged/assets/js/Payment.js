document.addEventListener("DOMContentLoaded", function () {
    // --- DOM elemek lekérése
    const submitPaymentButton = document.getElementById("submit-payment");
    const totalAmountElement = document.getElementById("total-amount");
    const cardPaymentSection = document.getElementById("card-payment-section");
  
    // Felvételi mezők a kiszállítási adatokhoz
    const firstNameInput = document.getElementById("first-name");
    const lastNameInput = document.getElementById("last-name");
    const addressInput = document.getElementById("address");
    const cityInput = document.getElementById("city");
    const zipInput = document.getElementById("zip");
    const phoneInput = document.getElementById("phone");
  
    // Felvételi mezők a bankkártyás adatokhoz
    const cardNumberInput = document.getElementById("card-number");
    const expiryDateInput = document.getElementById("expiry-date");
    const cvvInput = document.getElementById("cvv");
  
    // Fizetési mód radio input-ok
    const paymentMethodRadios = document.querySelectorAll("input[name='payment-method']");
  
    // Popup értesítő
    const showPopupNotification = (message) => {
      const popup = document.getElementById('popup-notification');
      popup.textContent = message;
      popup.style.opacity = '1';
      popup.style.animation = 'popupShow 0.5s forwards';
  
      setTimeout(() => {
        popup.style.animation = 'popupHide 0.5s forwards';
      }, 3000);
    };
  
    // --- Aktualizáljuk a végösszeget (példa logika: kosár adatokból) ---
    const getTotalAmount = () => {
      let cart = JSON.parse(localStorage.getItem('cart')) || [];
      let total = cart.reduce((sum, item) => {
        return sum + (parseFloat(item.finalPrice) * item.quantity);
      }, 0);
      return total.toFixed(0) + ' Ft';
    };
  
    const updateTotalAmount = () => {
      totalAmountElement.textContent = getTotalAmount();
    };
  
    updateTotalAmount();
  
    // --- Bankkártya formázása ---
    cardNumberInput.addEventListener("input", function () {
      let value = cardNumberInput.value.replace(/\D/g, "");
      value = value.slice(0, 16);
      value = value.match(/.{1,4}/g)?.join(" ") || "";
      cardNumberInput.value = value;
      clearError('card-number-error');
    });
  
    expiryDateInput.addEventListener("input", function () {
      let value = expiryDateInput.value.replace(/\D/g, "");
      if (value.length > 2) {
        value = value.slice(0, 2) + '/' + value.slice(2, 4);
      }
      expiryDateInput.value = value.slice(0, 5);
      clearError('expiry-date-error');
    });
  
    cvvInput.addEventListener("input", function () {
      cvvInput.value = cvvInput.value.replace(/\D/g, "").slice(0, 3);
      clearError('cvv-error');
    });
  
    // --- Hibakezelés ---
    const showError = (elementId, message) => {
      const errorElement = document.getElementById(elementId);
      errorElement.textContent = message;
      errorElement.style.display = 'block';
    };
  
    const clearError = (elementId) => {
      const errorElement = document.getElementById(elementId);
      errorElement.style.display = 'none';
    };
  
    // --- Fizetési mód kezelése ---
    paymentMethodRadios.forEach(radio => {
      radio.addEventListener("change", function () {
        // Ha a bankkártya opciót választják
        if (this.value === "card") {
          // Animáció: a rejtett szekció megjelenítése
          cardPaymentSection.classList.remove("hidden");
          cardPaymentSection.classList.add("show");
        } else {
          // Bankkártyás szekció elrejtése
          cardPaymentSection.classList.remove("show");
          cardPaymentSection.classList.add("hidden");
        }
      });
    });
  
    // --- Esetleges input korlátozások ---
    const restrictNameInput = (event) => {
      const input = event.target;
      input.value = input.value.replace(/[^a-zA-ZáéíóöőúüűÁÉÍÓÖŐÚÜŰ]/g, '');
    };
    firstNameInput.addEventListener("input", restrictNameInput);
    lastNameInput.addEventListener("input", restrictNameInput);
  
    const restrictCityInput = (event) => {
      const input = event.target;
      input.value = input.value.replace(/[^a-zA-ZáéíóöőúüűÁÉÍÓÖŐÚÜŰ\s]/g, '');
    };
    cityInput.addEventListener("input", restrictCityInput);
  
    const restrictZipInput = (event) => {
      const input = event.target;
      input.value = input.value.replace(/[^0-9]/g, '');
    };
    zipInput.addEventListener("input", restrictZipInput);
  
    phoneInput.addEventListener("input", function () {
      let value = phoneInput.value.replace(/\D/g, '');
      phoneInput.value = value;
      clearError('phone-error');
    });
  
    const validatePhoneNumber = (phone) => {
      const phoneRegex = /^[\+]?[0-9]{0,3}\W?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im;
      return phoneRegex.test(phone);
    };
  
    // --- Fizetés véglegesítése ---
    submitPaymentButton.addEventListener("click", function (event) {
      event.preventDefault();
    
      let isValid = true;
      
      // Érvényesítés: Kisállítási adatok
      if (!firstNameInput.value.trim()) {
        showError('first-name-error', 'Kötelező mező!');
        isValid = false;
      } else {
        clearError('first-name-error');
      }
      if (!lastNameInput.value.trim()) {
        showError('last-name-error', 'Kötelező mező!');
        isValid = false;
      } else {
        clearError('last-name-error');
      }
      if (!addressInput.value.trim()) {
        showError('address-error', 'Kötelező mező!');
        isValid = false;
      } else {
        clearError('address-error');
      }
      if (!cityInput.value.trim()) {
        showError('city-error', 'Kötelező mező!');
        isValid = false;
      } else {
        clearError('city-error');
      }
      if (!zipInput.value.trim()) {
        showError('zip-error', 'Kötelező mező!');
        isValid = false;
      } else {
        clearError('zip-error');
      }
      if (!phoneInput.value.trim()) {
        showError('phone-error', 'Kötelező mező!');
        isValid = false;
      } else {
        clearError('phone-error');
      }
      if (phoneInput.value.trim() && !validatePhoneNumber(phoneInput.value.trim())) {
        showError('phone-error', 'Hibás telefonszám formátum! Pl.: +36 30 1234567');
        isValid = false;
      } else {
        clearError('phone-error');
      }
    
      // Ha fizetési módként bankkártyát választottak, akkor a kártyaadatok validációja
      const selectedPaymentMethod = document.querySelector("input[name='payment-method']:checked").value;
      if (selectedPaymentMethod === "card") {
        let cardNumber = cardNumberInput.value.replace(/\s/g, "");
        if (!/^\d{16}$/.test(cardNumber)) {
          showError('card-number-error', 'Hibás kártyaszám! 16 számjegy szükséges.');
          isValid = false;
        } else {
          clearError('card-number-error');
        }
        let expiryDate = expiryDateInput.value.trim();
        if (!/^(0[1-9]|1[0-2])\/\d{2}$/.test(expiryDate)) {
          showError('expiry-date-error', 'Hibás lejárati dátum! Formátum: HH/ÉÉ');
          isValid = false;
        } else {
          clearError('expiry-date-error');
        }
        let cvv = cvvInput.value.trim();
        if (!/^\d{3}$/.test(cvv)) {
          showError('cvv-error', 'Hibás biztonsági kód! 3 számjegy szükséges.');
          isValid = false;
        } else {
          clearError('cvv-error');
        }
      }
    
      if (!isValid) return;
    
      // Ha minden validáció sikeres, megjelenítjük a popup értesítőt:
      showPopupNotification("Az adatok megfelelő formátumban lettek megadva.");
    
      // Ha készpénz fizetés:
      if (selectedPaymentMethod === "cash") {
        // Például az order_id-t elmenthetjük a kosárban vagy session-ben korábban
        // Itt egy egyszerű példa, ahol feltételezzük, hogy az order_id a localStorage-ban van tárolva:
        let orderId = localStorage.getItem('order_id') || 'temp_order_' + Date.now();
    
        // Készítsd el a payload-ot a backend API számára
        const payload = {
          city: cityInput.value.trim(),
          address: addressInput.value.trim(),
          postal_code: zipInput.value.trim(),
          phonenumber: phoneInput.value.trim(),
          order_id: orderId,
          // A status értéke a backendben default módon pending lesz,
          // de megadhatod itt, ha szükséges: status: "pending"
        };
    
        // Küldj egy POST kérést az API felé
        fetch('http://localhost/backend/Controller/delivery.php?action=payment', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(payload)
        })
        .then(response => response.json())
        .then(data => {
          if (data.success) {
            // Ha a rendelés rögzítése sikeres, irányítsd át a felhasználót a delivery.html-re
            window.location.href = "delivery.html";
          } else {
            // Hibakezelés, ha a backend hibaüzenetet ad vissza
            showPopupNotification("Hiba történt a rendelés feldolgozása során: " + data.error);
          }
        })
        .catch(error => {
          console.error('Hiba:', error);
          showPopupNotification("Váratlan hiba történt a kommunikáció során.");
        });
      } else {
        // Ha a választott fizetési mód nem készpénz (pl. bankkártya), itt kezelheted a megfelelő logikát.
        // Például elküldheted a kártyás adatokkal a fetch kérést vagy egy másik endpointot hívhatsz meg.
      }
    });    
  });
  
  document.addEventListener("DOMContentLoaded", function () {
    const radioButtons = document.querySelectorAll('input[name="payment-method"]');
    const cardSection = document.getElementById("card-payment-section");
  
    radioButtons.forEach(radio => {
      radio.addEventListener("change", function () {
        if (this.value === "card") {
          cardSection.style.display = "block";
          cardSection.style.animation = "popupShowCard 0.3s forwards";
        } else {
          cardSection.style.animation = "popupHideCard 0.3s forwards";
          setTimeout(() => {
            cardSection.style.display = "none";
          }, 300);
        }
      });
    });
  });

  
  