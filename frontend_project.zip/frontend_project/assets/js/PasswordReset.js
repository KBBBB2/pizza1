document.getElementById('resetPasswordForm').addEventListener('submit', function (e) {
    e.preventDefault();

    const usernameOrEmail = document.getElementById('reset_username').value;
    const messageDiv = document.getElementById('resetMessage');

    fetch('http://localhost:8000/Controller/account.php', {
        method: 'POST',
        credentials: 'include',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            action: 'reset_password',
            usernameOrEmail: usernameOrEmail
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            messageDiv.textContent = "A jelszó visszaállítási linket elküldtük az e-mail címedre.";
            messageDiv.style.color = "green";
        } else {
            messageDiv.textContent = data.error || "Hiba történt a jelszó visszaállítása során.";
            messageDiv.style.color = "red";
        }
    })
    .catch(error => {
        console.error("Hiba a jelszó visszaállítása során:", error);
        messageDiv.textContent = "Kapcsolódási hiba a szerverrel.";
        messageDiv.style.color = "red";
    });
});
