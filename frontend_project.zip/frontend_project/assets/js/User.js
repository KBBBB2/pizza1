document.addEventListener("DOMContentLoaded", function () {
    // Felhasználói adatok lekérése az oldal betöltésekor
    fetch('http://localhost:8000/Controller/account.php', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'getUserData' })
    })
    .then(response => response.json())
    .then(data => {
        if (data.user) {
            document.getElementById('firstname').value = data.user.firstname || "";
            document.getElementById('lastname').value  = data.user.lastname || "";
            document.getElementById('username').value  = data.user.username || "";
            document.getElementById('email').value     = data.user.email || "";
            document.getElementById('phonenumber').value = data.user.phonenumber || "";
        }
    })
    .catch(error => console.error('Hiba a felhasználói adatok lekérésekor:', error));

    // Mentés gomb eseménykezelője
    document.querySelector('.save-button').addEventListener('click', function () {
        const firstname = document.getElementById('firstname').value.trim();
        const lastname = document.getElementById('lastname').value.trim();
        const username = document.getElementById('username').value.trim();
        const email = document.getElementById('email').value.trim();
        const phonenumber = document.getElementById('phonenumber').value.trim();
        const currentPassword = document.getElementById('current-password').value.trim();
        const newPassword = document.getElementById('new-password').value.trim();

        let isValid = true;

        // Üres mezők ellenőrzése
        const fields = ['firstname', 'lastname', 'username', 'email', 'phonenumber'];
        fields.forEach(field => {
            if (!document.getElementById(field).value.trim()) {
                showError(field, 'Minden mezőt ki kell tölteni!');
                isValid = false;
            } else {
                clearError(field);
            }
        });

        // Telefonszám validálása
        const phoneRegex = /^[\+]?[0-9]{0,3}\W?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im;
        if (!phoneRegex.test(phonenumber)) {
            isValid = false;
            showError('phonenumber', 'Érvénytelen telefonszám formátum!');
        } else {
            clearError('phonenumber');
        }

        // Email validálása
        const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        if (!emailRegex.test(email)) {
            isValid = false;
            showError('email', 'Érvénytelen email formátum!');
        } else {
            clearError('email');
        }

        // Jelszó validálás (opcionális mező)
        if (newPassword && newPassword.length < 6) {
            isValid = false;
            showError('new-password', 'Az új jelszónak legalább 6 karakter hosszúnak kell lennie!');
        }

        if (newPassword && !currentPassword) {
            isValid = false;
            showError('current-password', 'Kérlek, add meg a jelenlegi jelszót, ha új jelszót szeretnél megadni!');
        }

        if (!isValid) return;

        const payload = {
            action: 'update',
            firstname: firstname,
            lastname: lastname,
            username: username,
            email: email,
            phonenumber: phonenumber,
            'current-password': currentPassword,
            'new-password': newPassword
        };

        fetch('http://localhost:8000/Controller/account.php', {
            method: 'POST',
            credentials: 'include',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                fields.forEach(field => updateSuccessMessage(field, 'Sikeresen frissítve'));
                clearError('current-password');
                clearError('new-password');
            } else {
                fields.forEach(field => showError(field, 'Hiba történt a módosítás során'));
            }
        })
        .catch(error => {
            console.error('Hiba a mentés során:', error);
        });
    });

    // Segédfüggvények
    function showError(fieldId, message) {
        const inputField = document.getElementById(fieldId);
        let errorElement = inputField.parentElement.querySelector('.error-message');

        if (errorElement) errorElement.remove();

        errorElement = document.createElement('div');
        errorElement.className = 'error-message';
        errorElement.textContent = message;
        inputField.parentElement.appendChild(errorElement);
    }

    function updateSuccessMessage(fieldId, message) {
        const inputField = document.getElementById(fieldId);
        let successElement = inputField.parentElement.querySelector('.success-message');

        if (successElement) successElement.remove();

        successElement = document.createElement('div');
        successElement.className = 'success-message';
        successElement.textContent = message;
        inputField.parentElement.appendChild(successElement);
    }

    function clearError(fieldId) {
        const inputField = document.getElementById(fieldId);
        const errorElement = inputField.parentElement.querySelector('.error-message');
        if (errorElement) errorElement.remove();
    }
});
