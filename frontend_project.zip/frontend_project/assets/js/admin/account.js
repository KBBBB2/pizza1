// Függvény, amely lekéri az account rekordokat, opcionálisan keresési feltétellel
function loadAccounts(query = '') {
  let url = 'http://localhost:8000/Controller/adminAccount.php?action=getAccounts';
  if (query !== '') {
      url += '&q=' + encodeURIComponent(query);
  }

  fetch(url)
      .then(response => response.json())
      .then(accounts => {
          const tbody = document.querySelector('#userTable tbody');
          tbody.innerHTML = ''; // Töröljük a meglévő sorokat

          accounts.forEach(account => {
              const row = document.createElement('tr');

              // Csak a szükséges oszlopok megjelenítése (id, password nélkül)
              row.innerHTML = `
                  <td>${account.lastname}</td>
                  <td>${account.firstname}</td>
                  <td>${account.username}</td>
                  <td>${account.email}</td>
                  <td>${account.phonenumber}</td>
                  <td>${account.created}</td>
                  <td>${account.locked == 1 ? 'Igen' : 'Nem'}</td>
                  <td>${account.disabled == 1 ? 'Igen' : 'Nem'}</td>
                  <td class="action-container">
                      <button class="temp-ban-btn">Ideiglenes tiltás</button>
                  </td>
              `;

              tbody.appendChild(row);

              // Akciók gombok
              const tempBanBtn = row.querySelector('.temp-ban-btn');
              tempBanBtn.addEventListener('click', function () {
                  // Ha még nincs megjelenítve a mező, akkor jelenjen meg egy input mező a tiltási idő megadásához
                  if (!row.querySelector('.tempDuration')) {
                      const durationInput = document.createElement('input');
                      durationInput.type = 'text';
                      durationInput.classList.add('tempDuration');
                      durationInput.placeholder = 'Pl. 5m, 2h, 1d';
                      row.querySelector('.action-container').appendChild(durationInput);
                  }
              });
          });
      })
      .catch(error => {
          console.error('Hiba történt a lekérés során:', error);
      });
}

// "Keresés" gomb eseménykezelője
document.getElementById('searchBtn').addEventListener('click', function () {
  const query = document.getElementById('search').value;
  loadAccounts(query);
});

// Oldal betöltésekor az account rekordok lekérése
window.onload = function () {
  loadAccounts();
};
