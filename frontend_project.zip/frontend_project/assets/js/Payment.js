document.addEventListener("DOMContentLoaded", function () {
    const payButton = document.querySelector(".pay-button");
    const totalAmountElement = document.getElementById("total-amount");
    const expiryDateInput = document.getElementById("expiry-date");
    const cardNumberInput = document.getElementById("card-number");
    const cvvInput = document.getElementById("cvv");
    const phoneInput = document.getElementById("phone");

    // Kártyaszám formázása, max 16 számjegy engedélyezése
    cardNumberInput.addEventListener("input", function () {
        let value = cardNumberInput.value.replace(/\D/g, "");
        value = value.slice(0, 16);
        value = value.match(/.{1,4}/g)?.join("-") || "";
        cardNumberInput.value = value;
        clearError('card-number-error');
    });

    // Lejárati dátum formázása (HH/ÉÉ), max 5 karakter engedélyezése
    expiryDateInput.addEventListener("input", function () {
        let value = expiryDateInput.value.replace(/\D/g, "");
        if (value.length > 2) {
            value = value.slice(0, 2) + '/' + value.slice(2, 4);
        }
        expiryDateInput.value = value.slice(0, 5);
        clearError('expiry-date-error');
    });

    // Biztonsági kód korlátozása max 3 számjegyre
    cvvInput.addEventListener("input", function () {
        cvvInput.value = cvvInput.value.replace(/\D/g, "").slice(0, 3);
        clearError('cvv-error');
    });

    // Kosár végösszegének lekérése
    const getTotalAmount = () => {
        let cart = JSON.parse(localStorage.getItem('cart')) || [];
        let total = cart.reduce((sum, item) => {
            return sum + (parseFloat(item.finalPrice) * item.quantity);
        }, 0);
        return total.toFixed(0) + ' Ft';
    };

    // Végösszeg frissítése
    const updateTotalAmount = () => {
        totalAmountElement.textContent = getTotalAmount();
    };

    // Hibaüzenet megjelenítése
    const showError = (elementId, message) => {
        const errorElement = document.getElementById(elementId);
        errorElement.textContent = message;
        errorElement.style.display = 'block';  // Üzenet megjelenítése
    };

    // Hibaüzenet eltüntetése
    const clearError = (elementId) => {
        const errorElement = document.getElementById(elementId);
        errorElement.style.display = 'none';  // Üzenet eltüntetése
    };

    const restrictNameInput = (event) => {
        const input = event.target;
        input.value = input.value.replace(/[^a-zA-ZáéíóöőúüűÁÉÍÓÖŐÚÜŰ]/g, ''); 
    };

    document.getElementById("first-name").addEventListener("input", restrictNameInput);
    document.getElementById("last-name").addEventListener("input", restrictNameInput);

    const restrictCityInput = (event) => {
        const input = event.target;
        input.value = input.value.replace(/[^a-zA-ZáéíóöőúüűÁÉÍÓÖŐÚÜŰ\s]/g, '');
    };

    document.getElementById("city").addEventListener("input", restrictCityInput);

    const restrictZipInput = (event) => {
        const input = event.target;
        input.value = input.value.replace(/[^0-9]/g, ''); 
    };

    document.getElementById("zip").addEventListener("input", restrictZipInput);

    // Telefonszám mező validálása, hogy csak számokat engedjünk
    phoneInput.addEventListener("input", function() {
        let value = phoneInput.value.replace(/\D/g, '');
        phoneInput.value = value;
        clearError('phone-error');
    });

    // Telefonszám validálása
    const validatePhoneNumber = (phone) => {
        const phoneRegex = /^[\+]?[0-9]{0,3}\W?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im;
        return phoneRegex.test(phone);
    };

    payButton.addEventListener("click", function (event) {
        event.preventDefault();

        // Fizetési adatok begyűjtése
        const cardNumber = cardNumberInput.value.replace(/-/g, "").trim();
        const expiryDate = expiryDateInput.value.trim();
        const cvv = cvvInput.value.trim();
        const firstName = document.getElementById("first-name").value.trim();
        const lastName = document.getElementById("last-name").value.trim();
        const address = document.getElementById("address").value.trim();
        const city = document.getElementById("city").value.trim();
        const zip = document.getElementById("zip").value.trim();
        const phone = document.getElementById("phone").value.trim();

        // Validáció
        let isValid = true;

        if (!/^\d{16}$/.test(cardNumber)) {
            showError('card-number-error', 'Hibás kártyaszám! 16 számjegy szükséges.');
            isValid = false;
        } else {
            clearError('card-number-error');
        }

        if (!/^(0[1-9]|1[0-2])\/\d{2}$/.test(expiryDate)) {
            showError('expiry-date-error', 'Hibás lejárati dátum! Formátum: HH/ÉÉ');
            isValid = false;
        } else {
            clearError('expiry-date-error');
        }

        if (!/^\d{3}$/.test(cvv)) {
            showError('cvv-error', 'Hibás biztonsági kód! 3 számjegy szükséges.');
            isValid = false;
        } else {
            clearError('cvv-error');
        }

        // Számlázási adatok validálása (kötelező mezők)
        if (!firstName || !lastName || !address || !city || !zip || !phone) {
            if (!firstName) showError('first-name-error', 'Mező kitöltése kötelező');
            if (!lastName) showError('last-name-error', 'Mező kitöltése kötelező');
            if (!address) showError('address-error', 'Mező kitöltése kötelező');
            if (!city) showError('city-error', 'Mező kitöltése kötelező');
            if (!zip) showError('zip-error', 'Mező kitöltése kötelező');
            if (!phone) showError('phone-error', 'Mező kitöltése kötelező');
            isValid = false;
        } else {
            clearError('first-name-error');
            clearError('last-name-error');
            clearError('address-error');
            clearError('city-error');
            clearError('zip-error');
            clearError('phone-error');
        }

        // Telefonszám validálása
        if (!validatePhoneNumber(phone)) {
            showError('phone-error', 'Hibás telefonszám formátum! +36 30 123 4567');
            isValid = false;
        } else {
            clearError('phone-error');
        }

        // Ha minden valid, folytatjuk a fizetést
        if (!isValid) {
            return;
        }

        // Küldés a szerverre
        fetch('http://localhost:8000/Controller/account.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                action: "processPayment",
                cardNumber: cardNumber,
                expiryDate: expiryDate,
                cvv: cvv,
                firstName: firstName,
                lastName: lastName,
                address: address,
                city: city,
                zip: zip,
                phone: phone
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert("Fizetés sikeres!");
                window.location.href = "Cart.html";
            } else {
                alert("Hiba történt a fizetés során: " + data.error);
            }
        })
        .catch(error => {
            console.error('Hiba:', error);
            alert("Hiba történt a tranzakció feldolgozása során.");
        });
    });

    // Figyeljük a kosár változásait
    window.addEventListener("storage", function (event) {
        if (event.key === 'cart') {
            updateTotalAmount();
        }
    });

    // Frissítjük a végösszeget az oldal betöltésekor
    updateTotalAmount();
});
