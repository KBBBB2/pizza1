document.addEventListener("DOMContentLoaded", function() {
    const addresses = [
        { id: 1, address: 'Budapest, Váci utca 1.', details: 'Csomag: 3 doboz', accepted: false },
        { id: 2, address: 'Pécs, Széchenyi tér 3.', details: 'Csomag: 1 doboz', accepted: false },
        { id: 3, address: 'Debrecen, Piac utca 4.', details: 'Csomag: 2 doboz', accepted: false },
    ];

    loadNavbar();

    function loadNavbar() {
        const navbar = document.getElementById('navbar');
        navbar.innerHTML = `
            <a href="/view/customer/mainpage.html">Customer nézet</a><br>
            <a href="/view/deliveryPerson/deliveryPerson.html">Futár Felület</a><br>
            <a href="#" id="logout-link">Kijelentkezés</a><br>
        `;
        
        document.getElementById('logout-link').addEventListener('click', function() {
            localStorage.removeItem("userRole");
            window.location.href = "/view/login.html";
        });
    }

    function displayAddresses() {
        const addressesList = document.getElementById('addresses');
        addressesList.innerHTML = ''; 

        addresses.forEach(address => {
            const li = document.createElement('li');
            li.innerHTML = `${address.address} <button onclick="viewDetails(${address.id})">Részletek</button>`;
            addressesList.appendChild(li);
        });
    }

    function viewDetails(id) {
        const address = addresses.find(a => a.id === id);
        if (address) {
            document.getElementById('address-detail').innerText = address.details;
            document.getElementById('accept-address').onclick = () => acceptAddress(id);
            document.getElementById('finalize-order').onclick = finalizeOrder;
            document.getElementById('delivery-detail').classList.remove('hidden');
            document.getElementById('address-list').classList.add('hidden');
        }
    }

    function acceptAddress(id) {
        const address = addresses.find(a => a.id === id);
        if (address) {
            address.accepted = true;
            showPopup(`${address.address} cím elfogadva.`);
        }
    }

    function finalizeOrder() {
        const acceptedAddress = addresses.find(a => a.accepted === true);

        if (!acceptedAddress) {
            showPopup("Kérlek válassz egy címet!");
            return;
        }

        const orderData = {
            city: acceptedAddress.address.split(',')[0],
            address: acceptedAddress.address,
            postal_code: '1234',
            phonenumber: '123456789',
            order_id: Date.now() 
        };

        fetch('/controllers/DeliveryController.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(orderData),
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showPopup(data.message);
            } else {
                showPopup(data.error);
            }
        })
        .catch(error => {
            console.error('Hiba történt a kérés során:', error);
            showPopup('Hiba történt a rendelés elküldése során');
        });

        document.getElementById('delivery-detail').classList.add('hidden');
        document.getElementById('address-list').classList.remove('hidden');
        displayAddresses(); 
    }

    function showPopup(message) {
        const popup = document.getElementById('popup');
        const popupMessage = document.getElementById('popup-message');
        
        popupMessage.textContent = message;

        popup.style.display = 'block';

        setTimeout(() => {
            popup.style.display = 'none';
        }, 2000);
    }

    displayAddresses();
});
