document.getElementById('loginForm').addEventListener('submit', function (e) {
    e.preventDefault();

    const username = document.getElementById('login_username').value;
    const password = document.getElementById('login_password').value;
    const messageDiv = document.getElementById('loginMessage');

    fetch('http://localhost:8000/Controller/account.php', {
        method: 'POST',
        credentials: 'include',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            action: 'login',
            username: username,
            password: password
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Mentjük a szerepkört, ha van
            if (data.user && data.user.role) {
                localStorage.setItem("userRole", data.user.role);
            }

            // Átirányítás sikeres bejelentkezés után
            window.location.href = "mainpage.html";
        } else {
            messageDiv.textContent = data.error || "Hiba történt a bejelentkezés során.";
            messageDiv.style.color = "red";
        }
    })
    .catch(error => {
        console.error("Hiba a bejelentkezés során:", error);
        messageDiv.textContent = "Kapcsolódási hiba a szerverrel.";
        messageDiv.style.color = "red";
    });
});

// Jelszó visszaállítási folyamat
document.getElementById('reset_password').addEventListener('click', function (e) {
    e.preventDefault();

    // Itt átirányíthatjuk a felhasználót a jelszó visszaállító oldalra
    window.location.href = "PasswordReset.html";
});
